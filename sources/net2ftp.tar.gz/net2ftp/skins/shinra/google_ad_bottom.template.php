<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/shinra/google_ad_bottom.template.php begin -->
<?php if ($net2ftp_settings["show_ads"] == "yes") { ?>
<div style="text-align: center; padding-top: 20px; padding-bottom: 10px;">
<script type="text/javascript"><!--
google_ad_client = "ca-pub-8420366685399799";
/* Net2Ftp_468x60_Bottom */
google_ad_slot = "8227392099";
google_ad_width = 468;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
<?php } // end if ?>
<!-- Template /skins/shinra/google_ad_bottom.template.php end -->
