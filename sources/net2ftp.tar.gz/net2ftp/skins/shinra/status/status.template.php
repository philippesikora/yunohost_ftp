<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/shinra/status/status.template.php begin -->
<!-- Template /skins/shinra/status/status.template.php end -->
