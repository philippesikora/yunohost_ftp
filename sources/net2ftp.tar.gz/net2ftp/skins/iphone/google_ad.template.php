<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/iphone/google_ad.template.php begin -->
<?php if ($net2ftp_settings["show_ads"] == "yes") { ?>
<div style="text-align: center;">
<script type="text/javascript"><!--
google_ad_client = "pub-8420366685399799";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_channel ="";
google_color_border = "336699";
google_color_bg = "FFFFFF";
google_color_link = "0000FF";
google_color_url = "008000";
google_color_text = "000000";
//--></script>
<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>
</div>
<?php } // end if ?>
<!-- Template /skins/iphone/google_ad.template.php end -->
