<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/shinra/footer.php begin -->
<div style="margin-top: 20px; text-align: center;">
	<a href="<?php echo printPHP_SELF("defaultskin"); ?>"><?php echo __("Standard"); ?></a> 
	| <b><?php echo __("Mobile"); ?></b></div>
<!-- Template /skins/shinra/footer.php end -->
