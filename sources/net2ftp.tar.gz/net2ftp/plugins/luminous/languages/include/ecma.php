<?php


require_once (dirname(__FILE__) . '/../ecmascript.php');
require_once (dirname(__FILE__) . '/../javascript.php');
require_once (dirname(__FILE__) . '/../html.php');
