<?php

define('LUMINOUS_DEBUG', false);
